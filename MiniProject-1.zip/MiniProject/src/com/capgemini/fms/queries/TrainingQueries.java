package com.capgemini.fms.queries;

public interface TrainingQueries {

	public String addTrainingProgram="INSERT INTO TRAINING_PROGRAM VALUES ( Training_Ids.nextval,?,?,?,?)";
	public String getTrainingId="SELECT Training_Ids.currval FROM DUAL";
	public String getCourseName="SELECT  CourseID,CourseName,NoOfDays from COURSE_MASTER";
	public String getCourseById="SELECT  CourseID,CourseName,NoOfDays from COURSE_MASTER WHERE CourseID=?";
	public String getFaculties="SELECT  Employee_ID  ,EmployeeName   from EMPLOYEE_MASTER where Employee_ID IN "
				+ "(SELECT FacultyId  from FACULTY_SKILL )";
	public String updateTraining="update TRAINING_PROGRAM set CourseID =?, FacultyCode =?, StartDate =?, EndDate =? where Training_code =?";
	public String getTrainingByid="SELECT  Training_code ,CourseID ,FacultyCode ,StartDate ,EndDate  from TRAINING_PROGRAM WHERE Training_code =?";
	public String deleteTraining="delete from  TRAINING_PROGRAM WHERE Training_code =?";
	public String addParticipant="INSERT INTO TRAINING_ENROLLMENT VALUES (?,?)";
	public String getTrainingCodeCourse="SELECT Training_code from TRAINING_PROGRAM WHERE CourseID = (select CourseID from COURSE_MASTER where CourseName =?)";

}
