package com.capgemini.fms.test;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Test;

import com.capgemini.fms.bean.FeedBack;
import com.capgemini.fms.dao.ParticipantDAO;
import com.capgemini.fms.dao.ParticipantDAOImpl;
import com.capgemini.fms.exception.FeedbackException;

public class ParticipantTest {
	ParticipantDAO dao=new ParticipantDAOImpl();

	@Test
	public void testGetTrainingListByParticipantID() throws FeedbackException {
		
		assertNotNull( dao.getTrainingListByParticipantID(13069));
	}

	@Test
	public void testGetTrainingList() throws FeedbackException {
		HashMap<Integer, String> map=new HashMap<Integer, String>();
		map.put(101,"Core Java");
		map.put(102, "Servlet");
		assertEquals(map, dao.getTrainingListByParticipantID(13069));
	}

	@Test
	public void testGetTrainingDetails() throws FeedbackException {
		assertNotNull(dao.getTrainingDetails(102));
	}

	
}
