package com.capgemini.fms.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream.GetField;
import java.util.HashMap;

import java.util.Iterator;

import com.capgemini.fms.bean.Employee;
import com.capgemini.fms.bean.FeedBack;
import com.capgemini.fms.bean.TrainingProgram;
import com.capgemini.fms.exception.FeedbackException;
import com.capgemini.fms.service.ParticipantService;
import com.capgemini.fms.service.ParticipantServiceImpl;

public class ParticipantHelper {
	BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	TrainingProgram trainingbean = new TrainingProgram();
	ParticipantService service = new ParticipantServiceImpl();
	FeedBack feedback = null;
	Employee employee;
	HashMap<Integer, String> map = new HashMap<Integer, String>();
	String confirm;
	String rating;
	String trainingId;
	String switchOption;
	String exitSwitchCase = "y";
	String comments;
	String suggestions;
	int counter;
	int validTrainingId;
	int fbPrsComm;
	int fbClrfyDbts;
	int fbTM;
	int fbHndOut;
	int fbHwSwNtwrk;

	public ParticipantHelper(int employeeId) {
		employee = new Employee(employeeId);
		displayTrainingList();
	}

	public void displayTrainingList() {
		try {
			map = service.getTrainingListByParticipantID(employee
					.getEmployeeId());
			
			System.out.println("Training List:");
			
			System.out.println("ID=Course");
			
			Iterator itr = map.entrySet().iterator();
			
			while (itr.hasNext())
				System.out.println(itr.next());
			
			System.out.println();
			
			System.out.println("1. Feedback Entry");
			System.out.println("0. Logout");
			confirm = reader.readLine();
			
			switch (confirm) {
			case "1":
				getTraineeId(map);
				break;

			case "0":
				new AdminHelper();
				break;
			default:

				System.err.println("Invalid option\n\n");
				displayTrainingList();
				break;
			}
		} catch (FeedbackException e) {
			System.out.println(e.getMessage());
			new AdminHelper();
		} catch (IOException e) {
			System.out.println(e.getMessage());
			new AdminHelper();
		}

	}

	public void getTraineeId(HashMap<Integer, String> map) {
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in))) {
			String check = null;
			counter=0;
			boolean flag = false;
			// **Training Id input from User**
			do {
				// do-while to ensure valid training id input
				do {
					System.out
							.println("Enter  training Id to give feedback('ID' in Training List)");
					// do-while to ensure integer input
					do {
						trainingId = reader.readLine();
						if (trainingId.trim().isEmpty()) {
							System.err.println("Trainee ID was left blank");
							getTraineeId(map);
						}
						if (!(ParticipantServiceImpl
								.validateStringForInteger(trainingId)))
							System.err.println("Enter integer Only");
					} while (!ParticipantServiceImpl
							.validateStringForInteger(trainingId));
					validTrainingId = Integer.parseInt(trainingId);
					if (!map.containsKey(validTrainingId)){
						counter++;
						System.err.println("Training Id Doesnt Exist");
					}
					switch (counter) {
					case 3:
						displayTrainingList();
						break;

					default:
						if((!map.containsKey(validTrainingId)) && counter>0)
						{
							if(counter<2)
						System.out.println("Enter correct ID in "+(3-counter)+" attempts");
							else
								System.out.println("Enter correct ID in next attempt ");
						}
						continue;
					}
				} while (!map.containsKey(validTrainingId));
				if (!(ParticipantServiceImpl.checkExistingFeedback(
						validTrainingId, employee.getEmployeeId())))
				{
					System.err
							.println("You have already given feedback for that training! ");
					System.out.println("Enter 'Y' to enter Feedback for other Trainings or any other key to exit !!");
					check = reader.readLine().trim().toUpperCase();
					if(!check.equals("Y"))
					{ 
						displayTrainingList();
					}
					else{
						flag = true;
					}
				}
				else{
					flag = false;
				}
			} while (flag);
			
			System.out.println(validTrainingId);
			// Retrieving Training Details for which Feedback is being taken
			trainingbean = service.getTrainingDetails(validTrainingId);
			displayFeedbackMenu();
		} catch (FeedbackException e) {
			// TODO Auto-generated catch block
			System.err.println("Something went Wrong:" + e.getMessage());
			displayTrainingList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			displayTrainingList();
		}
	}

	public void displayFeedbackMenu() {
		// Displaying feedback Menu
		System.out.println("Training ID:" + trainingbean.getTraining_code());
		System.out.println("Faculty ID:" + trainingbean.getFacultyCode());
		System.out
				.println("Ratings  for the Feedback can be of the following:");
		System.out.println("**Rating '5' :Excellent: �Ideal way of doing it� ");
		System.out
				.println("**Rating '4' :Good: �No pain areas or concern but could have been better� ");
		System.out
				.println("**Rating '3' :Average: �There are concerns but not significant� ");
		System.out
				.println("**Rating '2' :Below Average: �Needs improvement and is salvageable� ");
		System.out
				.println("**Rating '1' :Poor: �This way of doing things must change� ");
		do {
			System.out
					.println("enter 'Y' to start the  Feedback or 'B' to go back");
			try {
				confirm = reader.readLine();
			} catch (IOException e) {
				System.err.println("Something went wrong" + e.getMessage());
				displayFeedbackMenu();
			}
		} while (!(confirm.equalsIgnoreCase("y") || confirm
				.equalsIgnoreCase("b")));

		if (confirm.equalsIgnoreCase("y"))
			getFeedback();
		else
			displayTrainingList();
	}

	public void getFeedback() {
		try {

			// do-while to ensure ratings are between 0-6
			do {
				rating = "";
				System.out.println("Please Rate  from 1 to 5: ");
				System.out
						.print("1)Presentation and communication skills of faculty");
				do {
					rating = reader.readLine();
					if (!(ParticipantServiceImpl
							.validateStringForInteger(rating)))
						System.err.println("Enter valid integer");
				} while (!(ParticipantServiceImpl
						.validateStringForInteger(rating)));
				if (rating.isEmpty()) {
					fbPrsComm = 0;
					break;
				} else
					fbPrsComm = Integer.parseInt(rating);
				if (!(ParticipantServiceImpl.validateRating(fbPrsComm)))
					System.err.println("Enter your ratings from 1 to 5");
			} while (!(ParticipantServiceImpl.validateRating(fbPrsComm)));

			// do-while to ensure ratings are between 0-6
			do {
				rating = "";
				System.out.println("\nPlease Rate  from 1 to 5: ");
				System.out
						.print("2)Ability to clarify doubts and explain difficult points");
				do {
					rating = reader.readLine();
					if (!(ParticipantServiceImpl
							.validateStringForInteger(rating)))
						System.err.println("Enter valid integer");
				} while (!(ParticipantServiceImpl
						.validateStringForInteger(rating)));
				if (rating.isEmpty()) {
					fbClrfyDbts = 0;
					break;
				} else
					fbClrfyDbts = Integer.parseInt(rating);
				if (!(ParticipantServiceImpl.validateRating(fbClrfyDbts)))
					System.err.println("Enter your ratings from 1 to 5");
			} while (!(ParticipantServiceImpl.validateRating(fbClrfyDbts)));

			// do-while to en sure ratings are between 0-6
			do {
				rating = "";
				System.out.println("\nPlease Rate  from 1 to 5: ");
				System.out
						.print("3)Time management in completing the contents ");
				do {
					rating = reader.readLine();
					if (!(ParticipantServiceImpl
							.validateStringForInteger(rating)))
						System.err.println("Enter valid integer");
				} while (!(ParticipantServiceImpl
						.validateStringForInteger(rating)));
				if (rating.isEmpty()) {
					fbTM = 0;
					break;
				} else
					fbTM = Integer.parseInt(rating);
				if (!(ParticipantServiceImpl.validateRating(fbTM)))
					System.err.println("Enter your ratings from 1 to 5");
			} while (!(ParticipantServiceImpl.validateRating(fbTM)));

			// do-while to ensure ratings are between 0-6
			do {
				rating = "";
				System.out.println("\nPlease Rate  from 1 to 5: ");
				System.out.print("4)Handout provided(Student Guide)");
				do {
					rating = reader.readLine();
					if (!(ParticipantServiceImpl
							.validateStringForInteger(rating)))
						System.err.println("Enter valid integer");
				} while (!(ParticipantServiceImpl
						.validateStringForInteger(rating)));
				if (rating.isEmpty()) {
					fbHndOut = 0;
					break;
				} else
					fbHndOut = Integer.parseInt(rating);
				if (!(ParticipantServiceImpl.validateRating(fbHndOut)))
					System.err.println("Enter your ratings from 1 to 5");
			} while (!(ParticipantServiceImpl.validateRating(fbHndOut)));

			// do-while to ensure ratings are between 0-6
			do {
				rating = "";
				System.out.println("\nPlease Rate  from 1 to 5: ");
				System.out
						.print("5)Hardware, software and network availability");
				do {
					rating = reader.readLine();
					if (!(ParticipantServiceImpl
							.validateStringForInteger(rating)))
						System.err.println("Enter valid integer");
				} while (!(ParticipantServiceImpl
						.validateStringForInteger(rating)));
				if (rating.isEmpty()) {
					fbHwSwNtwrk = 0;
					break;
				} else
					fbHwSwNtwrk = Integer.parseInt(rating);
				if (!(ParticipantServiceImpl.validateRating(fbHwSwNtwrk)))
					System.err.println("Enter your ratings from 1 to 5");
			} while (!(ParticipantServiceImpl.validateRating(fbHwSwNtwrk)));

			// do-while for blank suggestion and String size validation
			do {
				confirm = "y";
				System.out.println("\n6)Any Suggestions?(Max 200 characters.)");
				suggestions = reader.readLine();

				if (suggestions.trim().isEmpty()) {
					System.out.println("Leave Suggestions empty? y/n");
					confirm = reader.readLine();
				} else {
					if (!(ParticipantServiceImpl
							.validateStringSize(suggestions))) {
						confirm = "n";
						System.err
								.println("Suggestion should not exceed 200 charachters!");
					}
				}
			} while (!(confirm.equalsIgnoreCase("y")));

			// do-while for blank comments and String size validation
			do {
				confirm = "y";
				System.out.println("7)Any Comments?");
				comments = reader.readLine();
				if (comments.trim().isEmpty()) {
					System.out.println("Leave Comments empty? y/n");
					confirm = reader.readLine();
				} else {
					if (!(ParticipantServiceImpl.validateStringSize(comments))) {
						confirm = "n";
						System.err
								.println("Comments should not exceed 200 charachters!");
					}
				}
			} while (!(confirm.equalsIgnoreCase("y")));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
		displayFeedbackSummary();
	}

	public void displayFeedbackSummary() {
		try {
			// Displaying Feedback details for confirmation
			System.out.println("\n***---Your Feedback summary---***");
			System.out.println();
			System.out
					.println("1)Presentation and communication skills of faculty: "
							+ fbPrsComm);
			System.out
					.println("2)Ability to clarify doubts and explain difficult points: "
							+ fbClrfyDbts);
			System.out.println("3)Time management in completing the contents: "
					+ fbTM);
			System.out
					.println("4)Handout provided(Student Guide): " + fbHndOut);
			System.out
					.println("5)Hardware, software and network availability: "
							+ fbHwSwNtwrk);
			System.out.println("6)Suggestions: " + suggestions);
			System.out.println("7)Comments: " + comments);
			// Confirmation to submit feedback
			String confirm1 = null;
			do {
				System.out
						.println("\nTo Submit,Enter 'Y'\nTo Make changes,enter 'N'");

				confirm1 = reader.readLine();
			} while (!(confirm1.trim().equalsIgnoreCase("y") || confirm1.trim()
					.equalsIgnoreCase("n")));
			if (confirm1.trim().equalsIgnoreCase("y")) {
				confirm = "";
				exitSwitchCase = "n";
				feedback = new FeedBack(trainingbean.getTraining_code(),
						employee.getEmployeeId(), fbPrsComm, fbClrfyDbts, fbTM,
						fbHndOut, fbHwSwNtwrk, comments, suggestions);
				if (!ParticipantServiceImpl.confirmEmptyValues(feedback)) {
					System.out
							.println("You have left some values blank which are displayed as '0' in the summary.");
					System.out
							.println("Enter 1 to proceed and submit feedback");
					System.out.println("Enter 2 to update values");
					do {
						System.out.println("Enter valid option");
						confirm = reader.readLine();
						switch (confirm) {
						case "1":
							addFeedBack();
							break;

						case "2":
							displayUpdateMenu();
							break;

						default:
							exitSwitchCase = "n";
							break;
						}

					} while (exitSwitchCase.equalsIgnoreCase("n"));

				} else
					addFeedBack();
			} else
				displayUpdateMenu();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void displayUpdateMenu() {
		// Displaying Update Menu

		System.out
				.println("1)Presentation and communication skills of faculty");
		System.out
				.println("2)Ability to clarify doubts and explain difficult points");
		System.out.println("3)Time management in completing the contents ");
		System.out.println("4)Handout provided(Student Guide)");
		System.out.println("5)Hardware, software and network availability");
		System.out.println("6)Suggestions:");
		System.out.println("7)Comments:");

		try {
			updateFeedback();
		} catch (FeedbackException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void updateFeedback() throws FeedbackException {
		try {
			// do-while for multiple updates
			do {
				confirm = "";
				exitSwitchCase = "n";
				System.out
						.println("Enter valid option from summary list to update");

				switchOption = reader.readLine();

				switch (switchOption) {

				case "1":
					System.out.println("Please Rate  from 1 to 5: ");
					// do-while to ensure ratings are between 0-6
					do {
						rating = "";

						System.out
								.println("Presentation and communication skills of faculty");
						System.out.println("You had rated:" + fbPrsComm);
						System.out.print("Enter new Rating:");
						// do-while for String vaidation
						do {
							rating = reader.readLine();
							if (!(ParticipantServiceImpl
									.validateStringForInteger(rating)))
								System.err.println("Enter valid integer");
						} while (!(ParticipantServiceImpl
								.validateStringForInteger(rating)));

						fbPrsComm = Integer.parseInt(rating);
						if (!(ParticipantServiceImpl.validateRating(fbPrsComm)))
							System.err
									.println("Enter your ratings from 1 to 5");
					} while (!(ParticipantServiceImpl.validateRating(fbPrsComm)));

					break;

				case "2":
					System.out.println("Please Rate  from 1 to 5: ");
					// do-while to ensure ratings are between 0-6
					do {
						rating = "";
						System.out
								.println("Ability to clarify doubts and explain difficult points");
						System.out.println("You had rated:" + fbPrsComm);
						System.out.print("Enter new Rating:");
						// do-while for String vaidation
						do {
							rating = reader.readLine();
							if (!(ParticipantServiceImpl
									.validateStringForInteger(rating)))
								System.err.println("Enter valid integer");
						} while (!(ParticipantServiceImpl
								.validateStringForInteger(rating)));
						fbClrfyDbts = Integer.parseInt(rating);
						if (!(ParticipantServiceImpl
								.validateRating(fbClrfyDbts)))
							System.err
									.println("Enter your ratings from 1 to 5");
					} while (!(ParticipantServiceImpl
							.validateRating(fbClrfyDbts)));

					break;

				case "3":
					System.out.println("Please Rate  from 1 to 5: ");
					// do-while to ensure ratings are between 0-6
					do {
						rating = "";
						System.out
								.println("Time management in completing the contents ");
						System.out.println("You had rated:" + fbTM);
						System.out.print("Enter new Rating:");
						// do-while for String vaidation
						do {
							rating = reader.readLine();
							if (!(ParticipantServiceImpl
									.validateStringForInteger(rating)))
								System.err.println("Enter valid integer");
						} while (!(ParticipantServiceImpl
								.validateStringForInteger(rating)));
						fbTM = Integer.parseInt(rating);
						if (!(ParticipantServiceImpl.validateRating(fbTM)))
							System.err
									.println("Enter your ratings from 1 to 5");
					} while (!(ParticipantServiceImpl.validateRating(fbTM)));

					break;

				case "4":
					System.out.println("Please Rate  from 1 to 5: ");
					// do-while to ensure ratings are between 0-6
					do {
						rating = "";
						System.out.println("Handout provided(Student Guide)");
						System.out.println("You had rated:" + fbHndOut);
						System.out.print("Enter new Rating:");
						// do-while for String vaidation
						do {
							rating = reader.readLine();
							if (!(ParticipantServiceImpl
									.validateStringForInteger(rating)))
								System.err.println("Enter valid integer");
						} while (!(ParticipantServiceImpl
								.validateStringForInteger(rating)));
						fbHndOut = Integer.parseInt(rating);
						if (!(ParticipantServiceImpl.validateRating(fbHndOut)))
							System.err
									.println("Enter your ratings from 1 to 5");
					} while (!(ParticipantServiceImpl.validateRating(fbHndOut)));

					break;

				case "5":
					System.out.println("Please Rate  from 1 to 5: ");
					// do-while to ensure ratings are between 0-6
					do {
						rating = "";
						System.out
								.println("Hardware, software and network availability");
						System.out.println("You had rated:" + fbHwSwNtwrk);
						System.out.print("Enter new Rating:");
						// do-while for String vaidation
						do {
							rating = reader.readLine();
							if (!(ParticipantServiceImpl
									.validateStringForInteger(rating)))
								System.err.println("Enter valid integer");
						} while (!(ParticipantServiceImpl
								.validateStringForInteger(rating)));
						fbHwSwNtwrk = Integer.parseInt(rating);
						if (!(ParticipantServiceImpl
								.validateRating(fbHwSwNtwrk)))
							System.err
									.println("Enter your ratings from 1 to 5");
					} while (!(ParticipantServiceImpl
							.validateRating(fbHwSwNtwrk)));
					break;
				case "6":
					// do-while for blank suggestion and String size validation
					do {
						confirm = "y";
						System.out.println("Edit Your Suggestion");
						suggestions = reader.readLine();
						if (suggestions.trim().isEmpty()) {
							System.out.println("Leave Suggestions empty? y/n");
							confirm = reader.readLine();
						} else {
							if (!ParticipantServiceImpl
									.validateStringSize(suggestions)) {
								confirm = "n";
								System.err
										.println("Suggestion should not exceed 200 charachters!");
							}
						}
					} while (!(confirm.equalsIgnoreCase("y")));
					break;
				case "7":
					// do-while for blank comments and String size validation
					do {
						confirm = "y";
						System.out.println("Edit your Comments");
						comments = reader.readLine();
						if (comments.trim().isEmpty()) {
							System.out.println("Leave Comments empty? y/n");
							confirm = reader.readLine();
						} else {
							if (!ParticipantServiceImpl
									.validateStringSize(comments)) {
								confirm = "n";
								System.err
										.println("Comments should not exceed 200 charachters!");
							}
						}
					} while (!(confirm.equalsIgnoreCase("y")));
					break;

				default:
					exitSwitchCase = "y";
					System.err.println("Wrong Value entered");
					break;
				}
				if (exitSwitchCase.equalsIgnoreCase("n")) {
					System.out.println("Want to update any more values? y/n");
					exitSwitchCase = reader.readLine();
				}
			} while (!(exitSwitchCase.trim().equalsIgnoreCase("n")));

			// feedback=new
			// FeedBackBean(trainingbean.getTrainingCode(),employee.getEmployeeId(),
			// fbPrsComm, fbClrfyDbts, fbTM, fbHndOut, fbHwSwNtwrk, comments,
			// suggestions);
			displayFeedbackSummary();
			// addFeedBack();
		} catch (Exception e) {

			System.out.println("Something went wrong " + e.getMessage());

		}
	}

	public void addFeedBack() {
		// Adding Feedback into Database
		try {
			service.addFeedback(feedback);
			confirm = null;
			System.out.println("1)Give more feedback?");
			System.out.println("2)Logout");
			System.out.println("Enter valid option");
			confirm = reader.readLine();
			switch (confirm) {
			case "1":
				displayTrainingList();
				break;
			case "2":
				new AdminHelper();
				break;

			default:
				System.out.println("enter valid option");
				break;
			}
		} catch (FeedbackException e) {
			// TODO Auto-generated catch block
			System.out.println("Something went Wrong:" + e.getMessage());
			displayTrainingList();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}
	}

}
