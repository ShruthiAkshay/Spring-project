package com.capgemini.fms.service;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Employee;
import com.capgemini.fms.bean.Faculty;
import com.capgemini.fms.dao.AdminDao;
import com.capgemini.fms.dao.AdminDaoImpl;
import com.capgemini.fms.exception.FeedbackException;

public class AdminServiceImpl implements AdminService {

	private AdminDao dao = new AdminDaoImpl();

	@Override
	public void addSkillSet(Faculty faculty) throws FeedbackException {

		dao.addSkillSet(faculty);
	}

	@Override
	public Employee getEmployeeById(int employeeId) throws FeedbackException  {

		return dao.getEmployeeById(employeeId);
		
	}

	@Override
	public HashMap<Integer, Employee> getEmployees() throws FeedbackException {
		
		return dao.getEmployees();
	}

	@Override
	public String getUser(int employeeId, String password) throws FeedbackException{

		return dao. getUser(employeeId, password);
	}

	@Override
	public int addCourse(Course course) throws FeedbackException {
		
		return dao.addCourse(course);
	}

	@Override
	public Map<Integer,Course> getCourses() throws FeedbackException {
	
		return dao.getCourses();
	}

	@Override
	public void deleteCourse(int courseId) throws FeedbackException {
		
		dao.deleteCourse(courseId);
	}

	@Override
	public void updateCourse(Course course) throws FeedbackException {

		dao.updateCourse(course);
		
	}

}
