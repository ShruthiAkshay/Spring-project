package com.capgemini.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;


import java.util.Map;

import org.apache.log4j.Logger;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Employee;
import com.capgemini.fms.bean.Faculty;
import com.capgemini.fms.exception.FeedbackException;
import com.capgemini.fms.logging.MyLogger;
import com.capgemini.fms.util.DBUtil;

public class AdminDaoImpl implements AdminDao {
	
	private Connection con = DBUtil.getConnect();
	MyLogger logger = new MyLogger();
	public Logger log = logger.getLog(); ;
	
	//Logs the Start Time of the Application
	public AdminDaoImpl() {
		log.info("Application Started" +"\t"+new Date());
	}
	
	//Takes an id and Returns the skill set for an employee
	public String getSkillset(int facultyId) throws FeedbackException
	{
		String skillSet= null;
		String sql = "SELECT SKILLSET FROM FACULTY_SKILL WHERE FACULTYID = ?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, facultyId);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				skillSet=rs.getString(1);
			}
			else
			{
				log.error("Error occured : Skills cannot be retrieved : Something went wrong "+"\t"+new Date());
				throw new FeedbackException("Skills cannot be retrieved : Something went wrong");
			}
			
		} catch (SQLException e) {
			log.error(e.getMessage() +"  "+new Date());
			throw new FeedbackException(e.getMessage());
		}
		return skillSet;
	}
	
	
	//This function adds the skill set for an employee
	@Override
	public void addSkillSet(Faculty faculty) throws FeedbackException {                 //Function to add Skill Set for Employee
		
		log.info("Adding Skill set" + faculty.getFacultyId()+" "+faculty.getSkillset()+" \t"+new Date());
		String sql = "INSERT INTO FACULTY_SKILL VALUES (?,?)";
		String skillSet = getSkillset( faculty.getFacultyId());
		skillSet += faculty.getSkillset();
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, faculty.getFacultyId());
			pstmt.setString(2, skillSet);
			int row = pstmt.executeUpdate();
			if(row == 1)
			{
				System.out.println("Faculty Skill-Set Inserted");
				log.info("Faculty Skill-Set Inserted"+"\t"+new Date());
			}
			else
			{
				log.error("Error occured : Skills cannot be set : Something went wrong "+"\t"+new Date());
				throw new FeedbackException("Skills cannot be set : Something went wrong");
			}
			
		} catch (SQLException e) {
			log.error(e.getMessage() +"  "+new Date());
			throw new FeedbackException(e.getMessage());
		}
	}
	
	//This function retrieves all the employees from the DB
	public HashMap<Integer, Employee> getEmployees() throws FeedbackException {           //Function to get Employee List
		HashMap<Integer, Employee> employees = null;
		log.info("Getting all Employees"+"\t"+new Date());
		String sql = "SELECT Employee_ID, EmployeeName, Role FROM EMPLOYEE_MASTER";
		try {
			employees = new HashMap<Integer, Employee>();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
				Employee employee = new Employee();
				employee.setEmployeeId(rs.getInt(1));
				employee.setEmployeeName(rs.getString(2));
				employees.put(employee.getEmployeeId(), employee);
			}
		} catch (SQLException e) {
			log.error(e.getMessage() +"\t"+new Date());
			throw new FeedbackException(e.getMessage());
		}
		log.info("EmployeeList Returned"+"\t"+new Date());
		return employees;
	}

		//This Function return the employee by id
	@Override
	public Employee getEmployeeById(int employeeId) throws FeedbackException {                //Function to get Employee by id
		Employee employee=null;
		log.info("Geting Employee By id "+ employeeId +"\t"+new Date());
		String sql = "SELECT Employee_ID, EmployeeName, Role FROM EMPLOYEE_MASTER WHERE Employee_ID =?";
		try{
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, employeeId);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next())
		{
			employee = new Employee();
			employee.setEmployeeId(rs.getInt(1));
			employee.setEmployeeName(rs.getString(2));
		}
	} catch (SQLException e) {
		log.error(e.getMessage() +"  "+new Date());
		throw new FeedbackException(e.getMessage());
	}
		log.info("Employee Record returned"+ employee +"\t"+new Date());
		return employee;
	}

	
	//Validate the user Credentials and return the role
	@Override
	public String getUser(int employeeId, String password) throws FeedbackException {              //Function to verify login Details
		String role = null;
		log.info("Checking login Details for "+employeeId+"\t"+new Date());
		String sql = "SELECT Role FROM EMPLOYEE_MASTER WHERE Employee_ID =? And Password =?";
		try{
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, employeeId);
		pstmt.setString(2, password);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next())
		{
			role = rs.getString(1);
			log.info("Login succeeded for " +role+" with id "+ employeeId+"\t"+new Date());
		}
		else {
			role = "noUser";
			log.error("Login Denied : Incoorect UserName or Password"+"\t"+new Date());
		}
	} catch (SQLException e) {
		log.error(e.getMessage() +"\t"+new Date());
		throw new FeedbackException(e.getMessage());
	}
		return role;
	}
	
	//Adds new Course to the Database
	public int addCourse(Course course) throws FeedbackException
	{
		int courseId = 0;
		String sql = "INSERT INTO COURSE_MASTER VALUES (course_Ids.nextVal,?,?)";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, course.getCourseName());
			pstmt.setInt(2, course.getDaysOfCourse());
			int row = pstmt.executeUpdate();
			if(row == 1)
			{
				log.info("Course Added"+"\t"+new Date());
				courseId = getCourseId();
			}
			else
			{
				log.error("Error occured : Cousre Cannot be Added : Something went wrong "+"\t"+new Date());
				throw new FeedbackException("Course Cannot be Added : Something went wrong");
			}
			
		} catch (SQLException e) {
			log.error(e.getMessage() +"  "+new Date());
			throw new FeedbackException(e.getMessage());
			//e.printStackTrace();
		}
		return courseId;
	}
	
	//Returns the Course id
	public int getCourseId() throws FeedbackException
	{
		int courseId = 0;
		String sql = "Select course_Ids.currval FROM DUAL";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next())
			{
				
				courseId = rs.getInt(1);
				log.info("Getting CousrId" + courseId +"\t"+new Date());
			}
			else
			{
				log.error("Error occured : Id Cannot be Retrieved : Something went wrong "+"\t"+new Date());
				throw new FeedbackException("Id Cannot be Retrieved : Something went wrong");
			}
			
		} catch (SQLException e) {
			log.error(e.getMessage() +"  "+new Date());
			throw new FeedbackException(e.getMessage());
			//e.printStackTrace();
		}
		return courseId;
	}
	
	
	//Retrieves all the courses from the database and returns a map of it 
	public Map<Integer,Course> getCourses() throws FeedbackException
	{
		Map<Integer,Course> courses = new HashMap<Integer, Course>();
		log.info("Retrieving Courses List"+"\t"+new Date());
		String sql = "Select CourseID,CourseName,NoOfDays FROM COURSE_MASTER";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
				Course course = new Course();
				course.setCourseId(rs.getInt(1));
				course.setCourseName(rs.getString(2));
				course.setDaysOfCourse(rs.getInt(3));
				courses.put(course.getCourseId(),course);
			}
			if(courses.isEmpty())
			{
				log.error("Error occured : list Cannot be Retrieved : Something went wrong "+"\t"+new Date());
				throw new FeedbackException("List Cannot be Retrieved : Something went wrong");
			}
			
		} catch (SQLException e) {
			log.error(e.getMessage() +"  "+new Date());
			throw new FeedbackException(e.getMessage());
			//e.printStackTrace();
		}
		
		return courses;
	}
	
	//This Function takes the course id and deletes a course from the Database
	public void deleteCourse(int courseId) throws FeedbackException
	{
		log.info("Deleting Course with id "+courseId+"\t"+new Date());
		String sql = "DELETE FROM COURSE_MASTER WHERE COURSEID = ?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, courseId);
			int row = pstmt.executeUpdate();
			if(row == 1)
			{
				System.out.println("Course Deleted Succesfully !!");
				log.info("Course deleted"+"\t"+new Date());
			}
			else
			{
				log.error("Error occured : Cousre Cannot be Added : Something went wrong "+"\t"+new Date());
				throw new FeedbackException("Course Cannot be Added : Something went wrong");
			}
			
		} catch (SQLException e) {
			log.error(e.getMessage() +" \t"+new Date());
			throw new FeedbackException(e.getMessage());
			//e.printStackTrace();
		}
	}
	
	//This function updates the course in the Database
	public void updateCourse(Course course) throws FeedbackException
	{
		log.info("Updating Course with id "+course.getCourseId()+"\t"+new Date());
		String sql = "UPDATE COURSE_MASTER SET CourseName = ? , NoOfDays = ? WHERE COURSEID = ?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, course.getCourseName());
			pstmt.setInt(2, course.getDaysOfCourse());
			pstmt.setInt(3, course.getCourseId());
			int row = pstmt.executeUpdate();
			if(row == 1)
			{
				System.out.println("Course Updated Succesfully !!");
				log.info("Course updated"+"\t"+new Date());
			}
			else
			{
				log.error("Error occured : Cousre Cannot be updated : Something went wrong "+"\t"+new Date());
				throw new FeedbackException("Course Cannot be updated : Something went wrong");
			}
			
		} catch (SQLException e) {
			log.error(e.getMessage() +"  "+new Date());
			throw new FeedbackException(e.getMessage());
			//e.printStackTrace();
		}
	}
}

