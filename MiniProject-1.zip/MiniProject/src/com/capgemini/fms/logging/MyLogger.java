package com.capgemini.fms.logging;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class MyLogger {

	public static Logger log = Logger.getLogger(MyLogger.class.getName());

	public MyLogger() {
		PropertyConfigurator.configure("log4j.properties");
	}

	public static Logger getLog() {
		return log;
	}
	
	
}
