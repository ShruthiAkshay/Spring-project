select * from EMPLOYEE_MASTER;

Insert into Employee_master values(10000,'Shazaan','shazaan','Participant');

Insert into Employee_master values(10001,'admin','admin','Admin');

Insert into Employee_master values(10002,'Nishank','nishank','Coordinator');

Insert into Employee_master values(10003,'Pallavi','pallavi','Participant');

Insert into Employee_master values(10004,'Prachi','prachi','Participant');

Insert into Employee_master values(10005,'Sanjivani','sanjivani','Participant');

Delete From EMPLOYEE_MASTER;

select * from COURSE_MASTER;


CREATE SEQUENCE Course_Ids 
	INCREMENT BY 1
	START WITH 1000
	MAXVALUE 10000
	NOCYCLE;
	
	Drop Sequence Cousre_ids;
	
	
	
Select * from Training_Enrollment;

Insert into TRAINING_ENROLLMENT values(1005,10000);

Select * from FEEDBACK_MASTER;